<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-12-29
 * Time: 17:27
 */
namespace EES\Model;

use Think\Model;

class OrderDetailModel extends Model
{
    protected $tableName='order_detail';
}