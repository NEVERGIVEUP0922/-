<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-12-29
 * Time: 17:25
 */
namespace EES\Model;

use Think\Model;

class OrderGoodsModel extends Model
{
}