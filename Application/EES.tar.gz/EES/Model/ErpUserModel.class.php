<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-01-02
 * Time: 14:16
 */
namespace EES\Model;

use Think\Model;

class ErpUserModel extends Model
{
    protected $trueTableName='sys_user';
}