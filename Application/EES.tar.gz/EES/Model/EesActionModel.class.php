<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-12-29
 * Time: 10:31
 */
namespace EES\Model;

use Think\Model;

class EesActionModel extends Model
{
    protected $tableName='ees_action';

}