<?php
// +----------------------------------------------------------------------
// | FileName:   ProductVisitCountModel.class.php
// +----------------------------------------------------------------------
// | Dscription:   
// +----------------------------------------------------------------------
// | Date:  2018-03-15 10:30
// +----------------------------------------------------------------------
// | Author: showkw <showkw@163.com>
// +----------------------------------------------------------------------
namespace Uba\Model\Count;

use Think\Model\MongoModel;


class ProductCountModedlModel extends MongoModel
{
	protected $tableName = 'product_count';
	
	protected $dbName = 'uba';
	
	
}